@echo off
title bokra
start msedge --app="https://bokra101.vercel.app" --window-size=1280,840 2>nul || start chrome --app="https://bokra101.vercel.app" --window-size=1280,840 2>nul || start https://bokra101.vercel.app
exit

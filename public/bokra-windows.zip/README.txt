bokra - Windows Standalone Edition
==================================

1. Double-click "bokra.bat" to launch the standalone desktop app window.
2. Double-click "Install-Desktop-Shortcut.cmd" to place a shortcut directly on your Windows desktop.
3. Fully offline-capable with local IndexedDB storage.
